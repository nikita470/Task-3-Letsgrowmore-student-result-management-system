<html>
<head>
    <title>About</title>
<link rel="stylesheet" href="../csss/aboutus.css" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Flamenco" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">

</head>
<body>
    <header>
      <nav>
        <div class="row clearfix">
            <ul class="main-nav" animate slideInDown>
                <li><a href="../index.php">Home </a></li>
                <li><a href="aboutus.php">About</a></li>
                <li><a href="contactus.php">Contact</a></li>
                <li><a href="../login.php">Admin login</a></li>
          </ul>
        </div>
      </nav>
      <div class="main-content-header">
          <h2 class="search">About Us</h2>
             <div class="div2">
             <h3>Student Result Management System</h2>
             <p> manage Student Result very Easy</p>
             <p> Efficient and Reliable</p>
             <p> Gives Result to the student in the as fundamental and Exact way as possible</p>

          </div>
    </header>
    
</body>
</html>